Laboratorio de Datos v2024
Trabajo Práctico 02
intregrantes:
    --> Manuel Andres Beren
    --> Sofia Roitman
    --> Dafne Sol Yudcovsky

Bibliotecas usadas y sus versiones:
- pandas v1.5.3
- matplotlib v3.8.3
- numpy v1.26.4
- SciKit-learn v1.4.1.post1


